//
//  AppDelegate.h
//  test01
//
//  Created by 豪哥 on 2018/5/16.
//  Copyright © 2018年 豪哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

