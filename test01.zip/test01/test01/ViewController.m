//
//  ViewController.m
//  test01
//
//  Created by 豪哥 on 2018/5/16.
//  Copyright © 2018年 豪哥. All rights reserved.
//

#import "ViewController.h"
#import "XHProgressView.h"

@interface ViewController ()
@property(nonatomic,strong)XHProgressView*progressView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(30, 44, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(addProgress:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    self.progressView = [[XHProgressView alloc]initWithFrame:CGRectMake(200, 44, 20, 100)];
    self.progressView.progressTintColor = [UIColor redColor];
    self.progressView.progressBackGroundColor = [UIColor whiteColor];
    [self.view addSubview:self.progressView];
    // Do any additional setup after loading the view, typically from a nib.
}
float a = 0;
-(void)addProgress:(UIButton*)sender{
    NSLog(@"12314141");
    a+=0.1;
    [self.progressView setProgressValue:a];
    [self.progressView layoutSubviews];
    [self.progressView setProgressValue:a];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
