//
//  XHProgressView.m
//  ShopApp
//
//  Created by DJM001 on 2018/5/16.
//  Copyright © 2018年 qinKiller. All rights reserved.
//

#import "XHProgressView.h"
@interface XHProgressView ()

@property (strong,nonatomic) UIView *firstView;
@property (strong,nonatomic) UIView *secondView;;

@end

@implementation XHProgressView
+ (instancetype)initCommenProgressView{
    return [[self alloc]init];
}

- (UIView *)firstView{
    if (_firstView == nil){
        UIView *fView = [[UIView alloc]init];
        fView.backgroundColor = _progressBackGroundColor;
        fView.layer.masksToBounds = YES;
        fView.layer.cornerRadius = _progressCornerRadius;
        fView.transform = CGAffineTransformRotate(fView.transform, M_PI);
        [self addSubview:fView];
        _firstView = fView;
    }
    return _firstView;
}

- (UIView *)secondView{
    if (_secondView == nil){
        UIView *sView = [[UIView alloc]init];
        sView.backgroundColor = _progressTintColor;
        sView.layer.masksToBounds = YES;
        sView.layer.cornerRadius = _progressCornerRadius;
        sView.transform = CGAffineTransformRotate(sView.transform, M_PI);
        [self.firstView addSubview:sView];
        _secondView = sView;
    }
    return _secondView;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.secondView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height* _progressValue);
    
    self.firstView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    
}

#pragma mark - set&&get
- (void)setProgressBackGroundColor:(UIColor *)progressBackGroundColor{
    
    _progressBackGroundColor = progressBackGroundColor;
}

- (void)setProgressValue:(CGFloat)progressValue{
    _progressValue = progressValue;
}

- (void)setProgressTintColor:(UIColor *)progressTintColor{
    self.layer.borderColor = progressTintColor.CGColor;
    
    _progressTintColor = progressTintColor;
}


- (void)setProgressCornerRadius:(NSInteger)progressCornerRadius{
    
    _progressCornerRadius = progressCornerRadius;
}

- (void)setProgressBorderWidth:(NSInteger)progressBorderWidth{
    self.layer.borderWidth = progressBorderWidth;
    _progressBorderWidth = progressBorderWidth;
}


@end
